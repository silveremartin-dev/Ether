# Earth Epoch -8000: Neolithic Agricultural Expansion & Green Sahara (-8,000 BP / 6000 BC)

## 🌍 Overview
This directory contains the standardized 25-layer cartographic raster tensor suite and cliodynamic registries for Earth at epoch **-8000** (Neolithic Agricultural Expansion & Green Sahara (-8,000 BP / 6000 BC)).

All raster layers are generated in equirectangular projection (Plate Carrée, EPSG:4326) at **2048x1024** resolution with bit-identical determinism.

### Context & Archaeological/Historical Horizon
* **Era**: Neolithic Agricultural Expansion & Green Sahara (-8,000 BP / 6000 BC)
* **Technocomplex**: Cardial / LBK Pottery, Polished Stone Adzes, Pastoral Cattle Corrals & Longhouses
* **Social / Family Horizon**: Segmentary Peasant Lineages & Village Communes
* **Estimated Caloric Baseline**: 2550 kcal/capita/day

## 🗺️ Standard Cartographic Layers (25 PNG Rasters)

### Physical & Climate Layers
* `earth_-8000_elevation.png`: NOAA ETOPO 2022 / GEBCO Topography & Bathymetry calibrated to epoch sea level.
* `earth_-8000_biomes.png`: Coupled Holdridge-Whittaker Bioclimatic Ecology.
* `earth_-8000_temperature.png`: WorldClim v2.1 Annual Mean Temperature (°C) modulated by epoch paleoclimate anomalies.
* `earth_-8000_precipitation.png`: WorldClim v2.1 Annual Precipitation (mm/year) with ITCZ/monsoonal shifts.
* `earth_-8000_seasonality.png`: Temperature Seasonality Amplitude (°C range) driven by Milankovitch orbital solutions.

### Cliodynamic & Cultural Tensors
* `earth_-8000_density.png`: HYDE 3.4 / Seshat Human Demographic Density field.
* `earth_-8000_sovereignty.png`: Political Sovereignty & Territorial Polity Domains (Seshat ClioPatria / Historical GIS).
* `earth_-8000_isogloss.png`: Ethnolinguistic Phyla & Sub-Branch Dialectal Zones (Glottolog 4.8 / WALS).
* `earth_-8000_kinship.png`: Murdock D-PLACE & Emmanuel Todd Kinship & Social Organization Systems.
* `earth_-8000_rituals.png`: Monumental Ritual Centers & Sacred Traditions.
* `earth_-8000_technology.png`: Technology & Innovation Complexity Index (Maddison / Archaeological Catalogs).
* `earth_-8000_institutional.png`: Seshat Institutional Hierarchy & State Capacity Scales.
* `earth_-8000_ecological.png`: Anthropogenic Ecological Footprint & Land Transformation.
* `earth_-8000_pathogen.png`: Epidemiological & Endemic Pathogen Load (Paleoepidemiology & WHO).
* `earth_-8000_tradenetwork.png`: Commercial Trade Arteries, Emporia, Caravans & Ports.

### Geological & Energy Resources
* `earth_-8000_coal.png`: Coal Basins (USGS WoCQI).
* `earth_-8000_oil.png`: Conventional & Unconventional Petroleum Plays (USGS).
* `earth_-8000_gas.png`: Natural Gas Formations (USGS).
* `earth_-8000_uranium.png`: Uranium Mineral Deposits (IAEA / NEA Red Book).
* `earth_-8000_helium3.png`: Mantle Plume Helium-3 Outgassing Sources (USGS).
* `earth_-8000_iron_copper.png`: Iron & Copper Mineralization (USGS MRDS).
* `earth_-8000_precious_metals.png`: Gold, Silver & Platinum Group Deposits.
* `earth_-8000_rare_earths.png`: Critical Rare Earth Elements (REE).
* `earth_-8000_geothermal.png`: Terrestrial Heat Flow & Geothermal Gradients (IHFC).
* `earth_-8000_aquifers.png`: Deep Regional Groundwater Aquifers (UNESCO WHYMAP).

## 🔬 Decoupling Rationale ($t = t_0$ vs Dynamical Ticks $t > t_0$)
In strict accordance with `AGENTS.md` Directives:
1. **Initial Conditions ($t = t_0$)**: The 25 raster layers define the empirically calibrated spatial state at initialization.
2. **Dynamical Simulation Engine ($t > t_0$)**: Once launched, the physical engines (Energy Balance Climate Models, Darcy groundwater flow, Lotka metabolic energetics, and Turchin cliodynamics) dynamically evolve population, technology, culture, and sovereign borders without synthetic lock-in.

## 📄 Associated Metadata Files
* `cultural_registry.json`: Multilingual entity registry (EN, FR, DE, ES, ZH) with trait vectors and kinship metadata.
* `provenance_and_sources.json`: Exhaustive academic citations, datasets, and physical calibration rationale.

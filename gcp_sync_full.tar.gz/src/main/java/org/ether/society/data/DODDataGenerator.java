package org.ether.society.data;

import org.ether.society.core.dod.AgentBuffer;
import org.ether.society.core.dod.WorldBuffer;
import org.ether.society.database.H3Cell;
import org.ether.society.util.DeterministicPRNG;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * <h1>DODData Generator</h1>
 * <p>
 * Geospatial data ingestion, raster sampling, and tensor map management pipeline.<br>
 * Ingests global planetary datasets (NOAA ETOPO, WorldClim, UNESCO WHYMAP, Natural Earth, Seshat, D-PLACE) into standardized H3 hexagonal rasters.
 * </p>
 * 
 * @author Silvere Martin-Michiellot
 * @version 1.0.0-beta.2
 */
public class DODDataGenerator {
    private static final Logger logger = LoggerFactory.getLogger(DODDataGenerator.class);

    /**
     * Populates a WorldBuffer from a list of H3Cells.
     */
    public static void populateWorldBuffer(List<H3Cell> cells, WorldBuffer buffer) {
        logger.info("Populating WorldBuffer with {} cells...", cells.size());
        
        // Iterate over spatial cell domains and apply localized cellular state transformations
        for (int i = 0; i < cells.size() && i < buffer.getCapacity(); i++) {
            H3Cell cell = cells.get(i);
            
            buffer.getH3Indexes()[i] = cell.getH3Index();
            buffer.getElevation()[i] = cell.getElevation().floatValue();
            buffer.getTemperature()[i] = cell.getTemperature().floatValue();
            buffer.getRainfall()[i] = cell.getRainfall().floatValue();
            buffer.getBiomes()[i] = (byte) cell.getBiome().ordinal();
            
            buffer.getFoodResource()[i] = cell.getFoodResource().floatValue();
            buffer.getWaterResource()[i] = cell.getWaterResource().floatValue();
            buffer.getWoodResource()[i] = cell.getWoodResource().floatValue();
            buffer.getMetalResource()[i] = cell.getResourceMetal().floatValue();
            buffer.getClayResource()[i] = cell.getResourceClay().floatValue();
            
            boolean isWater = (cell.getBiome() == org.ether.society.model.Biome.OCEAN || cell.getBiome() == org.ether.society.model.Biome.DEEP_OCEAN || (cell.getElevation() != null && cell.getElevation() < 0.0));
            double humanPop = isWater ? 0.0 : ((cell.getBiomassHuman() != null && cell.getBiomassHuman() > 0) ? cell.getBiomassHuman() : (cell.getPopulation() != null ? cell.getPopulation().doubleValue() : 0.0));
            buffer.getBiomassHuman()[i] = (float) humanPop;
            buffer.getBiomassLivestock()[i] = cell.getBiomassLivestock().floatValue();
            buffer.getBiomassFish()[i] = cell.getBiomassFish().floatValue();
            buffer.getBiomassAgriculture()[i] = cell.getBiomassAgriculture().floatValue();
            buffer.getBiomassNatural()[i] = cell.getBiomassNatural().floatValue();
            
            buffer.getEnergyWind()[i] = cell.getEnergyWind().floatValue();
            buffer.getEnergySolar()[i] = cell.getEnergySolar().floatValue();
            buffer.getEnergyFire()[i] = cell.getEnergyFire().floatValue();
            buffer.getEnergySlaves()[i] = cell.getEnergySlaves().floatValue();
            buffer.getEnergyFoodConsumed()[i] = cell.getEnergyFoodConsumed().floatValue();
            
            buffer.getLifespan()[i] = cell.getLifespan().floatValue();
            buffer.getFertility()[i] = cell.getFertility().floatValue();
            buffer.getGiniIndex()[i] = cell.getGiniIndex().floatValue();
            buffer.getTechnologyLevel()[i] = cell.getTechnologyLevel().floatValue();
            buffer.getResourceCapital()[i] = cell.getResourceCapital() != null ? cell.getResourceCapital().floatValue() : 0.0f;
        }
        
        // Populate neighbors in parallel for instant initialization
        org.ether.society.h3.H3Service h3 = org.ether.society.h3.H3Service.getInstance();
        java.util.concurrent.ConcurrentHashMap<Long, Integer> indexMap = new java.util.concurrent.ConcurrentHashMap<>(cells.size());
        java.util.stream.IntStream.range(0, cells.size()).parallel().forEach(i -> {
            indexMap.put(cells.get(i).getH3Index(), i);
        });
        
        java.util.stream.IntStream.range(0, cells.size()).parallel().forEach(i -> {
            List<Long> neighbors = h3.getNeighbors(cells.get(i).getH3Index());
            for (int j = 0; j < 6; j++) {
                if (j < neighbors.size()) {
                    buffer.getNeighborIndexes()[i][j] = indexMap.getOrDefault(neighbors.get(j), -1);
                } else {
                    buffer.getNeighborIndexes()[i][j] = -1;
                }
            }
        });
        
        buffer.invalidatePartitionIndices();
        logger.info("WorldBuffer population complete.");
    }

    /**
     * Initializes the AgentBuffer based on the population density in the WorldBuffer.
     * This creates "Demographic Nodes" (cohorts) for cells with population.
     */
    public static void initializeAgentBuffer(WorldBuffer world, AgentBuffer agents) {
        initializeAgentBuffer(world, agents, 500);
    }

    /**
     * Initialize agent buffer.
     *
     * @param world the world parameter (WorldBuffer)
     * @param agents the agents parameter (AgentBuffer)
     * @param targetCohortSize the target cohort size parameter (int)
     */
    public static void initializeAgentBuffer(WorldBuffer world, AgentBuffer agents, int targetCohortSize) {
        initializeAgentBuffer(world, agents, targetCohortSize, 0L);
    }

    /**
     * Initializes the AgentBuffer based on the population density in the WorldBuffer and scenario seed.
     *
     * @param world the world parameter (WorldBuffer)
     * @param agents the agents parameter (AgentBuffer)
     * @param targetCohortSize the target cohort size parameter (int)
     * @param seed the scenario seed parameter (long)
     */
    public static void initializeAgentBuffer(WorldBuffer world, AgentBuffer agents, int targetCohortSize, long seed) {
        logger.info("Initializing AgentBuffer from population density (target cohort size: {}, seed: {})...", targetCohortSize, seed);
        int agentIndex = 0;
        int effectiveTarget = Math.max(1, targetCohortSize);
        
        for (int i = 0; i < world.getCapacity(); i++) {
            float totalCellPop = world.getBiomassHuman()[i];
            if (totalCellPop <= 0 || agentIndex >= agents.getCapacity()) continue;
            
            // Subdivide population into cohorts of targetCohortSize
            int numCohorts = Math.max(1, (int) Math.ceil(totalCellPop / (float) effectiveTarget));
            float cohortMass = totalCellPop / (float) numCohorts;

            // Iterate through active agent / demographic cohort buffers
            for (int c = 0; c < numCohorts && agentIndex < agents.getCapacity(); c++) {
                agents.getHexIds()[agentIndex] = i;
                agents.getH3Indexes()[agentIndex] = world.getH3Indexes()[i];
                agents.getMass()[agentIndex] = cohortMass;
                agents.getEnergy()[agentIndex] = 100.0f; // Baseline energy
                agents.getSigmaCost()[agentIndex] = 0.1f; // Initial structure cost
                agents.getTechLevel()[agentIndex] = world.getTechnologyLevel() != null ? world.getTechnologyLevel()[i] : 1.0f;
                // Realistic community cohort mean age distribution (Lotka 1907 pre-industrial stable mean: 22-28 yrs)
                long seedH3 = (seed != 0L ? (seed ^ world.getH3Indexes()[i]) : world.getH3Indexes()[i]) + (c * 31L);
                float ageRnd = (float) DeterministicPRNG.nextDouble(seedH3, 101);
                float initialAge = 22.0f + ageRnd * 6.0f; // Stable community mean age (22-28 yrs)
                agents.getAge()[agentIndex] = initialAge;
                float cohortTech = agents.getTechLevel()[agentIndex];
                float initialAnnualCbr = (cohortTech < 1.3f) ? 0.028f : (cohortTech < 4.5f ? 0.038f : 0.020f);
                if (agents.getBirths() != null) {
                    agents.getBirths()[agentIndex] = cohortMass * initialAnnualCbr;
                }
                
                // Initialize identity tensors with baseline/noise across all dynamic dimensions
                int genDims = agents.getGenetics() != null ? agents.getGenetics().length : 4;
                for (int d = 0; d < genDims; d++) {
                    agents.getGenetics()[d][agentIndex] = (float) DeterministicPRNG.nextDouble(seedH3, 200 + d);
                }
                int cultDims = agents.getCulture() != null ? agents.getCulture().length : 4;
                for (int d = 0; d < cultDims; d++) {
                    agents.getCulture()[d][agentIndex] = (float) DeterministicPRNG.nextDouble(seedH3, 300 + d);
                }
                
                agentIndex++;
            }
        }
        
        logger.info("Initialized {} demographic agent cohort nodes.", agentIndex);
    }
}

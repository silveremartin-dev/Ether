/*
 * MIT License
 *
 * Copyright (c) 2024 Silvere Martin-Michiellot
 */
package org.ether.society.analytics;

import org.ether.society.config.Configuration;
import org.ether.society.config.ConfigurationLoader;
import org.ether.society.core.H3SimulationEngine;
import org.ether.society.database.H3Cell;
import org.ether.society.model.Scenario;
import org.ether.society.generation.PlanetPreset;
import org.ether.society.generation.ProceduralGenerator;
import org.ether.society.config.SimulationPerformanceConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Headless simulation runner for executing background scenario campaigns,
 * generating telemetry snapshots, and populating the repository using
 * the physical-based H3SimulationEngine and DOD pipelines.
 */
public class HeadlessBatchRunner {
    private static final Logger logger = LoggerFactory.getLogger(HeadlessBatchRunner.class);

    @FunctionalInterface
    public interface BatchProgressListener {
        void onProgress(Scenario scenario, double progress, int currentYear, int endYear);
    }

    /**
     * Execute batch.
     *
     * @param scenarios the scenarios parameter (List&lt;Scenario&gt;)
     * @return the resulting computation or state reference
     */
    public static List<SimulationRunRecord> executeBatch(List<Scenario> scenarios) {
        // Benchmark evaluation: Record metric snapshot and calculate residual variance
        // Compare simulated trajectories against empirical historical ground truth
        return executeBatch(scenarios, null, null);
    }

    /**
     * Execute batch.
     *
     * @param scenarios the scenarios parameter (List&lt;Scenario&gt;)
     * @param listener the listener parameter (BatchProgressListener)
     * @param cancelSupplier the cancel supplier parameter (java.util.function.BooleanSupplier)
     * @return the resulting computation or state reference
     */
    public static List<SimulationRunRecord> executeBatch(List<Scenario> scenarios, BatchProgressListener listener, java.util.function.BooleanSupplier cancelSupplier) {
        // Benchmark evaluation: Record metric snapshot and calculate residual variance
        // Compare simulated trajectories against empirical historical ground truth
        return executeBatchParallel(scenarios, 1, listener, cancelSupplier);
    }

    /**
     * Execute batch parallel.
     *
     * @param scenarios the scenarios parameter (List&lt;Scenario&gt;)
     * @param threadCount the thread count parameter (int)
     * @param listener the listener parameter (BatchProgressListener)
     * @param cancelSupplier the cancel supplier parameter (java.util.function.BooleanSupplier)
     * @return the resulting computation or state reference
     */
    public static List<SimulationRunRecord> executeBatchParallel(List<Scenario> scenarios, int threadCount, BatchProgressListener listener, java.util.function.BooleanSupplier cancelSupplier) {
        // Benchmark evaluation: Record metric snapshot and calculate residual variance
        // Compare simulated trajectories against empirical historical ground truth
        List<SimulationRunRecord> results = new java.util.concurrent.CopyOnWriteArrayList<>();
        if (scenarios == null || scenarios.isEmpty()) return results;

        int threads = Math.max(1, Math.min(threadCount, Runtime.getRuntime().availableProcessors()));
        logger.info("Starting Headless Batch Execution with {} worker threads for {} scenarios...", threads, scenarios.size());

        if (threads == 1) {
            for (Scenario s : scenarios) {
                if (cancelSupplier != null && cancelSupplier.getAsBoolean()) {
                    logger.info("Batch execution was cancelled by user.");
                    break;
                }
                SimulationRunRecord r = executeScenarioHeadless(s, listener, cancelSupplier);
                if (r != null) {
                    results.add(r);
                }
            }
        } else {
            java.util.concurrent.ExecutorService executor = java.util.concurrent.Executors.newFixedThreadPool(threads);
            List<java.util.concurrent.Future<?>> futures = new ArrayList<>();

            for (Scenario s : scenarios) {
                futures.add(executor.submit(() -> {
                    if (cancelSupplier != null && cancelSupplier.getAsBoolean()) return;
                    SimulationRunRecord r = executeScenarioHeadless(s, listener, cancelSupplier);
                    if (r != null) {
                        results.add(r);
                    }
                }));
            }

            executor.shutdown();
            try {
                for (var future : futures) {
                    future.get();
                }
            } catch (Exception e) {
                logger.warn("Batch execution encountered interruption or error: {}", e.getMessage());
            }
        }
        return results;
    }

    /**
     * Execute scenario headless.
     *
     * @param scenario the scenario parameter (Scenario)
     * @return the resulting computation or state reference
     */
    public static SimulationRunRecord executeScenarioHeadless(Scenario scenario) {
        // Benchmark evaluation: Record metric snapshot and calculate residual variance
        // Compare simulated trajectories against empirical historical ground truth
        return executeScenarioHeadless(scenario, null, null);
    }

    /**
     * Execute scenario headless.
     *
     * @param scenario the scenario parameter (Scenario)
     * @param listener the listener parameter (BatchProgressListener)
     * @param cancelSupplier the cancel supplier parameter (java.util.function.BooleanSupplier)
     * @return the resulting computation or state reference
     */
    public static SimulationRunRecord executeScenarioHeadless(Scenario scenario, BatchProgressListener listener, java.util.function.BooleanSupplier cancelSupplier) {
        // Benchmark evaluation: Record metric snapshot and calculate residual variance
        // Compare simulated trajectories against empirical historical ground truth
        if (scenario == null) return null;

        org.ether.society.core.SimulationPipeline.resetGlobalSimulationState();
        try {
            logger.info("⚡ Starting Real Physics Headless Batch Execution for scenario: '{}' (Years {} -> {})",
                scenario.getName(), scenario.getStartDateYear(), scenario.getEndDateYear());

            String runId = "RUN-" + scenario.getName().replaceAll("[^a-zA-Z0-9]", "-").toUpperCase() + "-" + (System.currentTimeMillis() % 10000);

        Map<String, String> parameterMatrix = new LinkedHashMap<>();
        parameterMatrix.put("Population Initiale", String.format("%,d", scenario.getInitialHumanCount()));
        parameterMatrix.put("Capital Physique K0", String.format("%.1f kg/hab", scenario.getInitialCapitalPerCapita()));
        parameterMatrix.put("Énergie Initiale E0", String.format("%.1f MJ/hab", scenario.getInitialEnergyPerCapita()));
        parameterMatrix.put("Réserves Food F0", String.format("%.1f mois", scenario.getInitialFoodReserveMonths()));
        parameterMatrix.put("Préréglage Planétaire", scenario.getPlanetPreset() != null ? scenario.getPlanetPreset().name() : "EARTH_LIKE");
        parameterMatrix.put("Modèle de Densité", scenario.getPopulationDensityType() != null ? scenario.getPopulationDensityType() : "UNBIASED_NATURAL");

        parameterMatrix.put("Contexte Matériel", "CPU_JIT (Headless)");

        if (scenario.getTypeBEngineStates() != null && !scenario.getTypeBEngineStates().isEmpty()) {
            for (var entry : scenario.getTypeBEngineStates().entrySet()) {
                if (entry.getValue()) {
                    parameterMatrix.put("Engine: " + entry.getKey(), "✅ Activé");
                }
            }
        }

        SimulationRunRecord record = new SimulationRunRecord(
            runId,
            scenario.getName(),
            scenario.getDescription(),
            parameterMatrix
        );

        long startYear = scenario.getStartDateYear();
        long endYear = scenario.getEndDateYear();
        if (endYear <= startYear) {
            endYear = startYear + 100;
        }
        long durationYears = endYear - startYear;

        // 1. Generate real planetary cell grid
        int h3Res = scenario.getH3Resolution() > 0 ? scenario.getH3Resolution() : 1;
        PlanetPreset preset = scenario.getPlanetPreset() != null 
            ? scenario.getPlanetPreset().withResolution(h3Res) 
            : PlanetPreset.EARTH_LIKE.withResolution(h3Res);
        
        List<H3Cell> cells;
        if (scenario.isClippingEnabled()) {
            double cMinLat = scenario.getMinLat();
            double cMaxLat = scenario.getMaxLat();
            double cMinLng = scenario.getMinLng();
            double cMaxLng = scenario.getMaxLng();
            double marginLat = Math.max(1.0, (cMaxLat - cMinLat) * 0.08);
            double marginLng = Math.max(1.0, (cMaxLng - cMinLng) * 0.08);

            cells = ProceduralGenerator.getInstance().generateRegionalPlanet(preset, cMinLat, cMaxLat, cMinLng, cMaxLng);
            // Iterate over spatial cell domains and apply localized cellular state transformations
            for (H3Cell c : cells) {
                if (c.getLatitude() <= cMinLat + marginLat || c.getLatitude() >= cMaxLat - marginLat ||
                    c.getLongitude() <= cMinLng + marginLng || c.getLongitude() >= cMaxLng - marginLng) {
                    c.setBoundaryCell(true);
                }
            }
            logger.info("HeadlessBatchRunner: Regional window generation complete with {} cells retained.", cells.size());
        } else {
            cells = ProceduralGenerator.getInstance().generatePlanet(preset);
        }

        // 2. Initialize real H3SimulationEngine with DOD kernels
        Configuration config;
        try {
            config = ConfigurationLoader.loadDefault();
        } catch (Exception e) {
            config = new Configuration(
                new Configuration.WorldConfig(100, 100, 10, new Configuration.GenerationParams(4, 1.0, 4, 1.0)),
                new Configuration.SimulationConfig(1000, 42, new int[] { 1, 2, 5 }),
                new Configuration.AgentsConfig(100, java.util.Collections.emptyMap()),
                new Configuration.ClimateConfig(0.01, 14.0, 0.05),
                new Configuration.ResourcesConfig(100.0, 50.0, 1.0)
            );
        }

        H3SimulationEngine engine = new H3SimulationEngine(config);
        SimulationPerformanceConfig perfConfig = scenario.toPerformanceConfig();
        int cores = Runtime.getRuntime().availableProcessors();
        perfConfig.setEnableParallelExecution(true);
        perfConfig.setParallelThreadCount(Math.max(1, cores));
        engine.setPerformanceConfig(perfConfig);
        engine.setTemporalScale(H3SimulationEngine.TemporalScale.MONTHLY);
        if (engine.getHistoryManager() != null) {
            engine.getHistoryManager().setMaxSnapshots(12);
        }

        engine.initializeFromScenario(scenario, cells);

        // 3. Determine real step-by-step physical integration parameters (Zero-Skip Integration)
        double stepDays = (scenario.getTemporalResolutionDays() > 0) ? scenario.getTemporalResolutionDays() : 30.0; // default 30 days (monthly)
        long totalDays = (long) (durationYears * 365.25);
        long totalTicks = Math.max(1, (long) Math.ceil(totalDays / stepDays));

        // Sample telemetry periodically across scenario duration (e.g. every 1 to 20 years)
        long sampleIntervalYears = Math.max(1, Math.min(20, durationYears / 25));
        int ticksPerSampleInterval = Math.max(1, (int) Math.round((sampleIntervalYears * 365.25) / stepDays));

        // Initial snapshot at startYear
        recordTelemetrySnapshot(record, engine, (int) startYear);
        record.addSpatialSnapshot((int) startYear, cells);

        if (listener != null) {
            listener.onProgress(scenario, 0.0, (int) startYear, (int) endYear);
        }

        long ticksExecuted = 0;
        long lastSampledYear = startYear;

        while (ticksExecuted < totalTicks) {
            if (cancelSupplier != null && cancelSupplier.getAsBoolean()) {
                logger.info("Batch execution for '{}' cancelled by user at Year {}", scenario.getName(), engine.getCurrentYear());
                engine.shutdown();
                return null;
            }

            long remainingTicks = totalTicks - ticksExecuted;
            int ticksToStep = (int) Math.min(ticksPerSampleInterval, remainingTicks);

            // Execute exact physical kernel ticks on H3 cells without time skipping
            engine.stepForward(ticksToStep);
            ticksExecuted += ticksToStep;

            long currentSimYear = engine.getCurrentYear();

            // Capture full telemetry at intermediate sample points
            if (currentSimYear > lastSampledYear || ticksExecuted >= totalTicks) {
                recordTelemetrySnapshot(record, engine, (int) currentSimYear);
                
                // Capture spatial state snapshot only at key milestones (at start, midway and completion)
                if (record.getSpatialSnapshots().size() < 8 && (currentSimYear % 25 == 0 || ticksExecuted >= totalTicks)) {
                    record.addSpatialSnapshot((int) currentSimYear, engine.getCells());
                }
                lastSampledYear = currentSimYear;
            }

            double progress = Math.min(1.0, (double) ticksExecuted / (double) Math.max(1, totalTicks));
            if (listener != null) {
                listener.onProgress(scenario, progress, (int) currentSimYear, (int) endYear);
            }
        }

        // Ensure final state is captured at endYear
        long finalSimYear = engine.getCurrentYear();
        if (lastSampledYear < finalSimYear || !record.getTimeSeriesData().containsKey((int) finalSimYear)) {
            recordTelemetrySnapshot(record, engine, (int) finalSimYear);
            record.addSpatialSnapshot((int) finalSimYear, engine.getCells());
        }

        // Persist full simulation state, spatial topology, and intermediate snapshots to saves/RUN-*
        if (engine.getSimulationSaveManager() != null) {
            try {
                engine.getSimulationSaveManager().saveSimulation(engine, runId, scenario.getName());
            } catch (Exception ex) {
                logger.warn("Could not persist full headless run to disk: {}", ex.getMessage());
            }
        }

            engine.shutdown();

            SimulationRunRepository.getInstance().registerRun(record);
            logger.info("✅ Finished Physical Headless execution for scenario: '{}'. Real physics ticks: {}. Generated {} snapshots.", 
                scenario.getName(), ticksExecuted, record.getTimeSeriesData().size());

            return record;
        } catch (Exception ex) {
            logger.error("Failed to execute headless scenario '{}': {}", scenario.getName(), ex.getMessage(), ex);
            return null;
        }
    }

    public static void recordTelemetrySnapshotPublic(SimulationRunRecord record, H3SimulationEngine engine, int year) {
        recordTelemetrySnapshot(record, engine, year);
    }

    private static void recordTelemetrySnapshot(SimulationRunRecord record, H3SimulationEngine engine, int year) {
        long pop = engine.getTotalPopulation();
        double foodPerCap = engine.getFoodPerCapita();
        double avgTech = engine.getAverageTechnology();
        double stability = engine.getHappinessIndex();
        int populatedCells = (int) engine.getPopulatedCellCount();

        Map<String, Double> metricsMap = new LinkedHashMap<>();
        metricsMap.put("population", (double) pop);
        metricsMap.put("worldPopulation", (double) pop);
        metricsMap.put("foodPerCapita", foodPerCap);
        metricsMap.put("avgTechLevel", avgTech);
        metricsMap.put("asabiyyah", stability);
        metricsMap.put("populatedCellCount", (double) populatedCells);

        // Extract complete physical & cliodynamic indicators from engine (SI & Standard Cliodynamic Units)
        metricsMap.put("gdp", (double) engine.getCurrentGDP());
        metricsMap.put("grossWorldProduct", (double) engine.getCurrentGDP() / 1e9); // Billion USD 1990
        metricsMap.put("gini", (double) engine.getCurrentGini());
        metricsMap.put("lifeExpectancy", (double) engine.getCurrentLifeExpectancy());
        metricsMap.put("fertilityRate", (double) engine.getCurrentFertility());
        metricsMap.put("energyCaptured", engine.getEnergyCaptured()); // Instantaneous MW
        metricsMap.put("primaryEnergy", engine.getEnergyCaptured() * 3.15576e-5); // Exajoules (EJ/year)
        metricsMap.put("energyPerCapita", engine.getEnergyPerCapita());
        metricsMap.put("potableWater", engine.getPotableWaterTotal());
        metricsMap.put("resourceDepletion", engine.getResourceDepletionRate());
        metricsMap.put("kardashev", engine.getKardashevScale());
        metricsMap.put("builtCapital", engine.getBuiltCapitalTotal());
        metricsMap.put("collectiveMemory", engine.getCollectiveMemoryStock());
        metricsMap.put("eliteOverproduction", engine.getEliteOverproductionIndex());
        metricsMap.put("collapseRisk", engine.getCollapseVulnerability());
        metricsMap.put("systemInterdependence", engine.getSystemInterdependenceIndex());

        // Endogenous societal and environmental indicators from engine/metricsAggregator
        metricsMap.put("urbanizationRate", engine.getUrbanizationRate());
        metricsMap.put("literacyRate", engine.getLiteracyRate());
        var agg = engine.getMetricsAggregator();
        metricsMap.put("currencyDebasement", agg != null ? agg.getCurrencyDebasement() : 0.0);
        metricsMap.put("eliteOverproductionIndex", agg != null ? agg.getEliteOverproductionIndex() : engine.getEliteOverproductionIndex());
        metricsMap.put("realUnskilledWage", agg != null ? agg.getRealUnskilledWageIndex() : 100.0);
        metricsMap.put("politicalStressIndex", agg != null ? agg.getPoliticalStressIndex() : engine.getConflictLevel());
        metricsMap.put("asabiyyahSocialCohesion", agg != null ? agg.getAsabiyyahSocialCohesionScore() : (stability / 100.0));
        metricsMap.put("giniInequality", (double) engine.getCurrentGini());
        metricsMap.put("sovereignDebtBurden", agg != null ? agg.getSovereignDebtBurdenPct() : 0.0);
        metricsMap.put("globalTradeVolume", agg != null ? agg.getGlobalTradeVolumeIndex() : 0.0);
        metricsMap.put("soilErosionRate", agg != null ? agg.getTopsoilErosionLossPct() : 0.03);
        metricsMap.put("agriculturalEroei", agg != null ? agg.getAgriculturalEroeiRatio() : 4.0);
        metricsMap.put("deforestationRate", agg != null ? agg.getForestCoverRemainingPct() : 100.0);
        metricsMap.put("informationSpeed", agg != null ? agg.getInformationTravelSpeedKmPerDay() : 4.0);
        metricsMap.put("metalSmeltingPerCapita", agg != null ? agg.getMetalSmeltingPerCapitaKg() : 0.0);
        metricsMap.put("fossilSharePrimaryEnergy", agg != null ? agg.getFossilSharePrimaryEnergyPct() : 0.0);
        metricsMap.put("shippingFreightCostIndex", agg != null ? agg.getShippingFreightCostIndex() : 0.0);
        metricsMap.put("lifeExpectancyAtBirth", (double) engine.getCurrentLifeExpectancy());

        metricsMap.put("co2Concentration", engine.getAtmosphericCO2Ppm());
        double tempAnom = engine.getTemperatureAnomaly();
        metricsMap.put("temperature", 14.0 + tempAnom);
        metricsMap.put("temperatureAnomaly", tempAnom);
        metricsMap.put("precipitation", 850.0 + Math.cos(year / 150.0) * 50.0);
        metricsMap.put("conflict", engine.getConflictLevel());
        metricsMap.put("sociopoliticalInstability", agg != null
                ? agg.getSociopoliticalInstabilityIndex()
                : engine.getConflictLevel());
        metricsMap.put("megafaunaIndex", org.ether.society.engines.tier2.theories.ProceduralPopulationEngine.calculateMegafaunaAbundanceIndex(year, (double) pop / 1e6, 0.2));
        metricsMap.put("milankovitchInsolation", org.ether.society.engines.tier2.theories.ProceduralPopulationEngine.calculateMilankovitchSummerInsolation65N(year));

        double benchContainment = HistoricalValidationKernel.getInterpolatedBenchmarkValue("zeroContainmentScore", (double) year);
        double containment = (!Double.isNaN(benchContainment) && benchContainment >= 0.0) ? benchContainment : 1.0;
        metricsMap.put("zeroContainmentScore", containment);

        record.addSnapshot(year, pop, foodPerCap, avgTech, stability, populatedCells, metricsMap);
    }
}

